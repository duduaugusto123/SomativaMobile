package appaula09.com.app_somativa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
